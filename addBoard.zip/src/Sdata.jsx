import theology from './Image/Theology.png'
import humanities from './Image/Hss.png'
import iT from './Image/IT.png'
import nursing from './Image/Nursing.png'
import music from './Image/Music.png'
import design from './Image/Design.png'

const Sdata = [

    {
        imgsrc: theology,
        title: "the department of Divinity",
    },

    {
        imgsrc: humanities,
        title: "the Faculty of Humanities and Social Sciences",
    },

    {
        imgsrc: iT,
        title: "the Faculty of IT",
    },

    {
        imgsrc: nursing,
        title: "the Faculty of Nursing",
    },

    {
        imgsrc: music,
        title: "Department of Musicc",
    },

    {
        imgsrc: design,
        title: "Department of Design Studies",
    },

];


export default Sdata;