import React from 'react'

const Footer= () => {
    return (
        <>
        <footer className="bg-light text-center">
          <p>© 2020 Update by HVP team. <br></br>This web was made by Jiseok.Lee</p>
        </footer>
        </>
    )

}


export default Footer;